package com.stockapi.training.notification;


import java.sql.*;

import com.stockapi.training.conectionBanco.PGConn;
public class Notification {

    public static void start() throws Exception {
        Connection lConn = PGConn.getConn();
        Listener listener = new Listener(lConn);
        listener.start();

    }

    
    public static void main(String[] args) throws Exception {
        start();
    }
}

class Listener extends Thread {

    private Connection conn;
    private org.postgresql.PGConnection pgconn;

    Listener(Connection conn) throws SQLException {
        this.conn = conn;
        this.pgconn = (org.postgresql.PGConnection) conn;
        Statement stmt = conn.createStatement();
        System.out.println("ESTOU NA LINHA 31");
        stmt.execute("LISTEN stocks");
        stmt.close();
    }

    public void run() {
        //long prev = 0l;
        while (true) {
            try {
                // Statement stmt = conn.createStatement();
                // ResultSet rs = stmt.executeQuery("SELECT 1");
                // rs.close();
                // stmt.close();

                org.postgresql.PGNotification notifications[] = pgconn.getNotifications();
                if (notifications != null) {
                   // System.out.println(notifications);
                    for (int i=0; i < notifications.length; i++)
                        System.out.println("Got notification: " + notifications[i].getName());
                }

            } catch (SQLException sqle) {
                sqle.printStackTrace();
            }
        }
    }

}
    