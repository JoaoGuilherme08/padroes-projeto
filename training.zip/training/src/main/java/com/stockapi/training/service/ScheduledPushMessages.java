package com.stockapi.training.service;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.github.javafaker.Faker;
import com.stockapi.training.model.OutputMessage;

import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class ScheduledPushMessages {
    private final SimpMessagingTemplate simpMessagingTemplate;

    private final Faker faker;

    public ScheduledPushMessages(SimpMessagingTemplate simpMessagingTemplate) {
        this.simpMessagingTemplate = simpMessagingTemplate;
        faker = new Faker();
    }

    @Scheduled(fixedRate = 5000)
    public void sendMessage() {
        System.out.println("ScheduledPushMessages com delay 5");
        final String time = new SimpleDateFormat("HH:mm").format(new Date());
        simpMessagingTemplate.convertAndSend("/topic/pushmessages", new OutputMessage("Chuck Norris", faker.chuckNorris().fact(), time));
    }

}
